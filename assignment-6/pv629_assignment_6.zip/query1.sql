SELECT sum(ff) as nyc_ff_jan18 FROM fares_jan18;

