SELECT count(*) FROM stations;
