SELECT name FROM stations WHERE line='Broadway';
